# Main scene quick setup

1. Create `Main.unity`.
2. Create `NetworkManager` GameObject.
3. Add `NetworkManager` and `UnityTransport`.
4. In NetworkManager assign UnityTransport and Player Prefab.
5. Player prefab must contain: NetworkObject, CharacterController, NetworkTransform (server authority), NetworkPlayerController, NetworkPlayerHealth.
6. Add child Camera and Muzzle; assign references in NetworkPlayerController.
7. Add `MatchNetworkState` to a NetworkObject spawned as a scene NetworkObject, or register it as a network prefab and spawn it from the server. For the simplest prototype, create a separate network prefab and spawn it after host starts.
8. Add `SessionMenu`, `DustyardBlockoutGenerator`, and `QuickSessionDebugUI` to a Bootstrap GameObject; assign SessionMenu reference.
9. Add the scene to Build Profiles.

Important: NetworkBehaviours such as MatchNetworkState must live on a spawned NetworkObject. Do not leave it as a plain scene MonoBehaviour.
