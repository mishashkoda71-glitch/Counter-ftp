#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace CounterFTP.EditorTools
{
    public static class AndroidBuildConfigurator
    {
        private const string OutputDirectory = "Builds/Android";
        private const string OutputApk = OutputDirectory + "/CounterFTP.apk";

        [MenuItem("Counter FTP/Android/Configure Android APK")]
        public static void ConfigureAndroid()
        {
            EditorUserBuildSettings.SwitchActiveBuildTarget(
                BuildTargetGroup.Android, BuildTarget.Android);

            PlayerSettings.companyName = "Counter FTP Studio";
            PlayerSettings.productName = "Counter FTP";
            PlayerSettings.applicationIdentifier = "com.counterftp.mobile";
            PlayerSettings.bundleVersion = "0.1.0";
            PlayerSettings.Android.bundleVersionCode = 1;
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.LandscapeLeft;
            PlayerSettings.allowedAutorotateToLandscapeLeft = true;
            PlayerSettings.allowedAutorotateToLandscapeRight = true;
            PlayerSettings.allowedAutorotateToPortrait = false;
            PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;
            PlayerSettings.SetScriptingBackend(
                BuildTargetGroup.Android, ScriptingImplementation.IL2CPP);
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel26;
            PlayerSettings.Android.targetSdkVersion = AndroidSdkVersions.AndroidApiLevelAuto;
            PlayerSettings.stripEngineCode = true;
            PlayerSettings.MTRendering = false;

            // Current prototype uses Unity's legacy Input API (Input.GetAxis / GetButton).
            // Enable old input handling so the existing controls work on Android builds.
            PlayerSettings.activeInputHandler = ActiveInputHandler.InputManager;

            Debug.Log("Counter FTP Android settings configured. Check Build Profiles and scenes.");
            EditorUtility.DisplayDialog(
                "Counter FTP",
                "Android settings configured.\n\nNext: add Main scene to Build Profiles, then Build APK.",
                "OK");
        }

        [MenuItem("Counter FTP/Android/Build APK")]
        public static void BuildApk()
        {
            ConfigureAndroid();

            string[] scenes = GetEnabledScenes();
            if (scenes.Length == 0)
            {
                EditorUtility.DisplayDialog(
                    "Counter FTP",
                    "No enabled scenes found. Create Assets/Scenes/Main.unity and add it to Build Profiles.",
                    "OK");
                return;
            }

            Directory.CreateDirectory(OutputDirectory);
            var options = new BuildPlayerOptions
            {
                scenes = scenes,
                locationPathName = OutputApk,
                target = BuildTarget.Android,
                options = BuildOptions.None
            };

            BuildReport report = BuildPipeline.BuildPlayer(options);
            if (report.summary.result == BuildResult.Succeeded)
            {
                Debug.Log($"APK created: {Path.GetFullPath(OutputApk)}");
                EditorUtility.RevealInFinder(OutputApk);
                EditorUtility.DisplayDialog("Counter FTP", "APK build succeeded:\n" + OutputApk, "OK");
            }
            else
            {
                Debug.LogError("APK build failed: " + report.summary.result);
                EditorUtility.DisplayDialog(
                    "Counter FTP",
                    "APK build failed. Open Console and inspect the first error.",
                    "OK");
            }
        }

        private static string[] GetEnabledScenes()
        {
            var scenes = EditorBuildSettings.scenes;
            var enabled = new System.Collections.Generic.List<string>();
            foreach (var scene in scenes)
            {
                if (scene.enabled && !string.IsNullOrWhiteSpace(scene.path))
                    enabled.Add(scene.path);
            }
            return enabled.ToArray();
        }
    }
}
#endif
