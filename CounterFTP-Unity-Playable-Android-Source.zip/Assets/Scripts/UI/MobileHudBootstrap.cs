using CounterFTP.Player;
using UnityEngine;

namespace CounterFTP.UI
{
    /// <summary>Attach to Bootstrap. Installs touch controls on Android; desktop controls remain available.</summary>
    public sealed class MobileHudBootstrap : MonoBehaviour
    {
        private void Awake()
        {
            if (Application.isMobilePlatform && MobileControls.Instance == null)
                gameObject.AddComponent<MobileControls>();
        }
    }
}
