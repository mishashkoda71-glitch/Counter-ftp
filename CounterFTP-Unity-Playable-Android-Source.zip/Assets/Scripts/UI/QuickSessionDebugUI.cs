using CounterFTP.Networking;
using Unity.Netcode;
using UnityEngine;

namespace CounterFTP.UI
{
    /// <summary>Temporary host/join panel and live 10-player counter. Replace IMGUI with production UI.</summary>
    public sealed class QuickSessionDebugUI : MonoBehaviour
    {
        [SerializeField] private SessionMenu session;
        private string _address = "127.0.0.1";
        private string _port = "7777";

        private void OnGUI()
        {
            if (session == null) return;

            GUILayout.BeginArea(new Rect(16, 16, 330, 280), GUI.skin.box);
            GUILayout.Label("COUNTER FTP // 5v5 TACTICAL");
            GUILayout.Label($"PLAYERS: {GetPlayerCount()}/10");
            GUILayout.Label($"SESSION: {GetSessionStatus()}");
            GUILayout.Label("HOST IP");
            _address = GUILayout.TextField(_address);
            GUILayout.Label("UDP PORT");
            _port = GUILayout.TextField(_port);

            if (ushort.TryParse(_port, out ushort port)) session.Port = port;
            session.Address = _address;

            GUI.enabled = NetworkManager.Singleton != null && !NetworkManager.Singleton.IsListening;
            if (GUILayout.Button("CREATE MATCH — HOST / SERVER")) session.HostGame();
            if (GUILayout.Button("JOIN MATCH — CLIENT")) session.JoinGame();
            GUI.enabled = NetworkManager.Singleton != null && NetworkManager.Singleton.IsListening;
            if (GUILayout.Button("DISCONNECT")) session.LeaveGame();
            GUI.enabled = true;
            GUILayout.Label("Round length: 02:30");
            GUILayout.EndArea();
        }

        private int GetPlayerCount()
        {
            var manager = NetworkManager.Singleton;
            return manager != null && manager.IsListening ? manager.ConnectedClientsIds.Count : 0;
        }

        private string GetSessionStatus()
        {
            var manager = NetworkManager.Singleton;
            if (manager == null || !manager.IsListening) return "OFFLINE";
            return manager.IsHost ? "HOST (SERVER + PLAYER)" : manager.IsServer ? "SERVER" : "CLIENT";
        }
    }
}
