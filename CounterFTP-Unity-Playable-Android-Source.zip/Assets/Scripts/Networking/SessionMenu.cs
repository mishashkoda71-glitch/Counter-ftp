using Unity.Netcode;
using Unity.Netcode.Transports.UTP;
using UnityEngine;

namespace CounterFTP.Networking
{
    /// <summary>
    /// Embedded listen-server session. The host is both player 1 and the server.
    /// Ten means ten total connections, including the host.
    /// </summary>
    public sealed class SessionMenu : MonoBehaviour
    {
        public const int MaxPlayers = 10;

        [SerializeField] private string address = "127.0.0.1";
        [SerializeField] private ushort port = 7777;

        public string Address { get => address; set => address = value; }
        public ushort Port { get => port; set => port = value; }

        private NetworkManager Manager => NetworkManager.Singleton;

        private void Awake()
        {
            if (Manager == null)
            {
                Debug.LogError("NetworkManager is missing from the scene.");
                return;
            }

            // NGO counts the host as one connected client. MaxConnectedClients=10
            // therefore allows host + up to nine remote players.
            Manager.NetworkConfig.MaxConnectedClients = MaxPlayers;
            Manager.OnClientConnectedCallback += OnClientConnected;
            Manager.OnClientDisconnectCallback += OnClientDisconnected;
        }

        private void OnDestroy()
        {
            if (Manager == null) return;
            Manager.OnClientConnectedCallback -= OnClientConnected;
            Manager.OnClientDisconnectCallback -= OnClientDisconnected;
        }

        public void HostGame()
        {
            if (Manager == null) return;
            var transport = Manager.GetComponent<UnityTransport>();
            if (transport == null)
            {
                Debug.LogError("Add UnityTransport to the NetworkManager GameObject.");
                return;
            }

            Manager.NetworkConfig.MaxConnectedClients = MaxPlayers;
            // Bind on all local interfaces. Remote LAN clients connect to the host's LAN IP.
            transport.SetConnectionData("0.0.0.0", port, "0.0.0.0");

            if (!Manager.StartHost())
                Debug.LogError("Host startup failed. Check Player Prefab and NetworkManager configuration.");
            else
                Debug.Log($"COUNTER FTP embedded Unity server started. UDP:{port}; capacity:{MaxPlayers} total players.");
        }

        public void JoinGame()
        {
            if (Manager == null) return;
            var transport = Manager.GetComponent<UnityTransport>();
            if (transport == null)
            {
                Debug.LogError("Add UnityTransport to the NetworkManager GameObject.");
                return;
            }

            transport.SetConnectionData(address, port);
            if (!Manager.StartClient())
                Debug.LogError($"Could not connect to {address}:{port}");
        }

        public void LeaveGame()
        {
            if (Manager != null && Manager.IsListening)
                Manager.Shutdown();
        }

        private void OnClientConnected(ulong clientId)
        {
            if (!Manager.IsServer) return;

            // Team assignment: first half T, second half CT.
            // Production matchmaking should balance by party/skill and support reconnects.
            var playerObject = Manager.SpawnManager.GetPlayerNetworkObject(clientId);
            if (playerObject == null) return;

            var team = playerObject.GetComponent<CounterFTP.Player.NetworkPlayerTeam>();
            if (team == null) return;

            int connected = Manager.ConnectedClientsIds.Count;
            team.SetTeamServer(connected <= MaxPlayers / 2
                ? CounterFTP.Player.TeamId.Terrorists
                : CounterFTP.Player.TeamId.CounterTerrorists);
        }

        private void OnClientDisconnected(ulong clientId)
        {
            if (Manager != null && Manager.IsServer)
                Debug.Log($"Player {clientId} disconnected. Players online: {Manager.ConnectedClientsIds.Count}");
        }
    }
}
