using Unity.Netcode;
using UnityEngine;

namespace CounterFTP.Networking
{
    /// <summary>Server-authoritative round clock and score state.</summary>
    public sealed class MatchNetworkState : NetworkBehaviour
    {
        public const int RoundLengthSeconds = 150;

        public NetworkVariable<int> SecondsRemaining = new(
            RoundLengthSeconds, NetworkVariableReadPermission.Everyone, NetworkVariableWritePermission.Server);

        public NetworkVariable<int> TerroristScore = new(
            0, NetworkVariableReadPermission.Everyone, NetworkVariableWritePermission.Server);

        public NetworkVariable<int> CounterTerroristScore = new(
            0, NetworkVariableReadPermission.Everyone, NetworkVariableWritePermission.Server);

        private float _nextTick;

        public override void OnNetworkSpawn()
        {
            if (IsServer)
            {
                SecondsRemaining.Value = RoundLengthSeconds;
                _nextTick = Time.time + 1f;
            }
        }

        private void Update()
        {
            if (!IsServer || SecondsRemaining.Value <= 0) return;
            if (Time.time < _nextTick) return;

            _nextTick = Time.time + 1f;
            SecondsRemaining.Value = Mathf.Max(0, SecondsRemaining.Value - 1);
        }

        public void AddRoundPoint(bool terroristsWon)
        {
            if (!IsServer) return;
            if (terroristsWon) TerroristScore.Value++;
            else CounterTerroristScore.Value++;
            SecondsRemaining.Value = RoundLengthSeconds;
        }
    }
}
