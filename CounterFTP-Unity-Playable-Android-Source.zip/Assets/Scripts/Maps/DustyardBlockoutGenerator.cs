using UnityEngine;

namespace CounterFTP.Maps
{
    /// <summary>
    /// Generates an original greybox tactical arena for early gameplay tests.
    /// Replace primitive geometry with licensed/original art before release.
    /// </summary>
    public sealed class DustyardBlockoutGenerator : MonoBehaviour
    {
        [SerializeField] private bool generateOnStart = true;
        [SerializeField] private float floorSize = 90f;
        [SerializeField] private Material wallMaterial;
        [SerializeField] private Material siteMaterial;

        private void Start()
        {
            if (generateOnStart) Generate();
        }

        [ContextMenu("Generate Dustyard Blockout")]
        public void Generate()
        {
            Transform old = transform.Find("GeneratedMap");
            if (old != null)
            {
                if (Application.isPlaying) Destroy(old.gameObject);
                else DestroyImmediate(old.gameObject);
            }

            var root = new GameObject("GeneratedMap").transform;
            root.SetParent(transform, false);

            Cube(root, "Ground", new Vector3(0, -0.5f, 0), new Vector3(floorSize, 1, floorSize), new Color(0.42f, 0.38f, 0.31f));
            // Outer perimeter and three lanes.
            Cube(root, "North wall", new Vector3(0, 2, 42), new Vector3(90, 4, 2), Color.gray);
            Cube(root, "South wall", new Vector3(0, 2, -42), new Vector3(90, 4, 2), Color.gray);
            Cube(root, "West wall", new Vector3(-42, 2, 0), new Vector3(2, 4, 86), Color.gray);
            Cube(root, "East wall", new Vector3(42, 2, 0), new Vector3(2, 4, 86), Color.gray);

            // Mid lane cover.
            Cube(root, "Mid cover 1", new Vector3(-8, 1.2f, 0), new Vector3(10, 2.4f, 3), Color.gray);
            Cube(root, "Mid cover 2", new Vector3(12, 1.2f, 8), new Vector3(3, 2.4f, 12), Color.gray);
            Cube(root, "Long cover", new Vector3(0, 1.5f, 25), new Vector3(16, 3, 3), Color.gray);

            // Bombsite A / B markers.
            Site(root, "Bombsite A", new Vector3(27, 0.05f, 25), new Color(0.75f, 0.18f, 0.12f));
            Site(root, "Bombsite B", new Vector3(-27, 0.05f, -25), new Color(0.12f, 0.32f, 0.75f));

            // Crates provide simple cover.
            Crate(root, new Vector3(22, 1, 12));
            Crate(root, new Vector3(29, 1, 16));
            Crate(root, new Vector3(-22, 1, -12));
            Crate(root, new Vector3(-29, 1, -16));
            Crate(root, new Vector3(2, 1, -18));
        }

        private void Site(Transform parent, string name, Vector3 position, Color color)
        {
            var marker = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            marker.name = name;
            marker.transform.SetParent(parent, false);
            marker.transform.position = position;
            marker.transform.localScale = new Vector3(12, 0.08f, 12);
            var renderer = marker.GetComponent<Renderer>();
            renderer.material = siteMaterial != null ? siteMaterial : new Material(Shader.Find("Standard"));
            renderer.material.color = color;
        }

        private void Crate(Transform parent, Vector3 position)
        {
            Cube(parent, "Tactical crate", position, new Vector3(3, 2, 3), new Color(0.35f, 0.28f, 0.18f));
        }

        private void Cube(Transform parent, string name, Vector3 position, Vector3 scale, Color color)
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Cube);
            go.name = name;
            go.transform.SetParent(parent, false);
            go.transform.position = position;
            go.transform.localScale = scale;
            var renderer = go.GetComponent<Renderer>();
            renderer.material = wallMaterial != null ? wallMaterial : new Material(Shader.Find("Standard"));
            renderer.material.color = color;
        }
    }
}
