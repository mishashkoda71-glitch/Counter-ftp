using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace CounterFTP.Player
{
    /// <summary>
    /// Runtime-generated touch HUD: left virtual stick, right look pad, fire/jump/reload.
    /// Attach once to a scene Bootstrap object. No prefab wiring is required.
    /// </summary>
    public sealed class MobileControls : MonoBehaviour
    {
        public static MobileControls Instance { get; private set; }

        public Vector2 Move { get; private set; }
        public Vector2 LookDelta { get; private set; }
        public bool FireHeld { get; private set; }
        public bool JumpPressed { get; private set; }
        public bool ReloadPressed { get; private set; }

        private Canvas _canvas;
        private TouchStick _stick;
        private LookPad _look;
        private HoldButton _fire;
        private HoldButton _jump;
        private HoldButton _reload;

        private void Awake()
        {
            if (Instance != null && Instance != this) { Destroy(gameObject); return; }
            Instance = this;
            DontDestroyOnLoad(gameObject);
            BuildHud();
        }

        private void LateUpdate()
        {
            if (_stick != null) Move = _stick.Value;
            if (_look != null) LookDelta += _look.ConsumeDelta();
            if (_fire != null) FireHeld = _fire.IsHeld;
            if (_jump != null && _jump.ConsumePress()) JumpPressed = true;
            if (_reload != null && _reload.ConsumePress()) ReloadPressed = true;
        }

        public Vector2 ConsumeLookDelta()
        {
            Vector2 value = LookDelta;
            LookDelta = Vector2.zero;
            return value;
        }

        public bool ConsumeJump()
        {
            bool value = JumpPressed;
            JumpPressed = false;
            return value;
        }

        public bool ConsumeReload()
        {
            bool value = ReloadPressed;
            ReloadPressed = false;
            return value;
        }

        private void BuildHud()
        {
            if (FindObjectOfType<EventSystem>() == null)
            {
                var es = new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));
                DontDestroyOnLoad(es);
            }

            var canvasObject = new GameObject("Mobile HUD", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            canvasObject.transform.SetParent(transform, false);
            _canvas = canvasObject.GetComponent<Canvas>();
            _canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            _canvas.sortingOrder = 100;
            var scaler = canvasObject.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920, 1080);
            scaler.matchWidthOrHeight = 0.5f;

            _stick = CreateWidget<TouchStick>("Move Stick", new Vector2(0.14f, 0.20f), new Vector2(230, 230));
            _look = CreateWidget<LookPad>("Look Area", new Vector2(0.73f, 0.48f), new Vector2(760, 760));
            _fire = CreateButton("FIRE", new Vector2(0.88f, 0.25f), new Vector2(150, 150), new Color(0.78f, 0.12f, 0.12f, 0.88f));
            _jump = CreateButton("JUMP", new Vector2(0.78f, 0.15f), new Vector2(100, 90), new Color(0.12f, 0.18f, 0.28f, 0.88f));
            _reload = CreateButton("RELOAD", new Vector2(0.91f, 0.43f), new Vector2(110, 80), new Color(0.12f, 0.18f, 0.28f, 0.88f));

            CreateLabel("COUNTER FTP", new Vector2(0.08f, 0.94f), 26, Color.white);
            CreateLabel("MOVE", new Vector2(0.14f, 0.05f), 18, Color.white);
            CreateLabel("LOOK", new Vector2(0.70f, 0.05f), 18, Color.white);
        }

        private T CreateWidget<T>(string name, Vector2 anchor, Vector2 size) where T : Component
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Image), typeof(T));
            go.transform.SetParent(_canvas.transform, false);
            var rt = go.GetComponent<RectTransform>();
            rt.anchorMin = rt.anchorMax = anchor;
            rt.anchoredPosition = Vector2.zero;
            rt.sizeDelta = size;
            var image = go.GetComponent<Image>();
            image.color = new Color(0.15f, 0.18f, 0.23f, 0.28f);
            return go.GetComponent<T>();
        }

        private HoldButton CreateButton(string label, Vector2 anchor, Vector2 size, Color color)
        {
            var go = new GameObject(label, typeof(RectTransform), typeof(Image), typeof(HoldButton));
            go.transform.SetParent(_canvas.transform, false);
            var rt = go.GetComponent<RectTransform>();
            rt.anchorMin = rt.anchorMax = anchor;
            rt.anchoredPosition = Vector2.zero;
            rt.sizeDelta = size;
            go.GetComponent<Image>().color = color;
            var hold = go.GetComponent<HoldButton>();
            hold.SetLabel(label);
            return hold;
        }

        private void CreateLabel(string value, Vector2 anchor, int fontSize, Color color)
        {
            var go = new GameObject(value, typeof(RectTransform), typeof(Text));
            go.transform.SetParent(_canvas.transform, false);
            var rt = go.GetComponent<RectTransform>();
            rt.anchorMin = rt.anchorMax = anchor;
            rt.anchoredPosition = Vector2.zero;
            rt.sizeDelta = new Vector2(360, 55);
            var text = go.GetComponent<Text>();
            text.text = value;
            text.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            text.fontSize = fontSize;
            text.color = color;
            text.alignment = TextAnchor.MiddleCenter;
        }
    }

    public sealed class TouchStick : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
    {
        public Vector2 Value { get; private set; }
        private RectTransform _rect;
        private void Awake() => _rect = (RectTransform)transform;

        public void OnPointerDown(PointerEventData eventData) => OnDrag(eventData);

        public void OnDrag(PointerEventData eventData)
        {
            if (RectTransformUtility.ScreenPointToLocalPointInRectangle(_rect, eventData.position,
                    eventData.pressEventCamera, out Vector2 local))
            {
                Vector2 half = _rect.rect.size * 0.5f;
                Value = Vector2.ClampMagnitude(new Vector2(local.x / half.x, local.y / half.y), 1f);
            }
        }

        public void OnPointerUp(PointerEventData eventData) => Value = Vector2.zero;
    }

    public sealed class LookPad : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
    {
        private Vector2 _last;
        private Vector2 _delta;
        private bool _active;

        public void OnPointerDown(PointerEventData eventData)
        {
            _last = eventData.position;
            _active = true;
        }

        public void OnDrag(PointerEventData eventData)
        {
            if (!_active) return;
            Vector2 current = eventData.position;
            _delta += (current - _last) * 0.12f;
            _last = current;
        }

        public void OnPointerUp(PointerEventData eventData) => _active = false;

        public Vector2 ConsumeDelta()
        {
            Vector2 value = _delta;
            _delta = Vector2.zero;
            return value;
        }
    }

    public sealed class HoldButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler
    {
        public bool IsHeld { get; private set; }
        private bool _pressed;
        private Text _label;

        public void SetLabel(string value)
        {
            _label = GetComponentInChildren<Text>();
            if (_label == null)
            {
                var go = new GameObject("Label", typeof(RectTransform), typeof(Text));
                go.transform.SetParent(transform, false);
                var rt = go.GetComponent<RectTransform>();
                rt.anchorMin = Vector2.zero;
                rt.anchorMax = Vector2.one;
                rt.offsetMin = rt.offsetMax = Vector2.zero;
                _label = go.GetComponent<Text>();
                _label.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
                _label.fontSize = 22;
                _label.fontStyle = FontStyle.Bold;
                _label.alignment = TextAnchor.MiddleCenter;
                _label.color = Color.white;
            }
            _label.text = value;
        }

        public void OnPointerDown(PointerEventData eventData)
        {
            IsHeld = true;
            _pressed = true;
        }

        public void OnPointerUp(PointerEventData eventData) => IsHeld = false;

        public bool ConsumePress()
        {
            bool value = _pressed;
            _pressed = false;
            return value;
        }
    }
}
