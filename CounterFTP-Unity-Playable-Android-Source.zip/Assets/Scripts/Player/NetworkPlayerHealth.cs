using Unity.Netcode;
using UnityEngine;

namespace CounterFTP.Player
{
    public sealed class NetworkPlayerHealth : NetworkBehaviour
    {
        [SerializeField] private int maxHealth = 100;

        public NetworkVariable<int> Health = new(
            100, NetworkVariableReadPermission.Everyone, NetworkVariableWritePermission.Server);

        public override void OnNetworkSpawn()
        {
            if (IsServer) Health.Value = maxHealth;
        }

        public void ApplyDamage(int amount)
        {
            if (!IsServer || amount <= 0) return;
            Health.Value = Mathf.Max(0, Health.Value - Mathf.Clamp(amount, 0, 100));
            if (Health.Value == 0)
                Debug.Log($"Player {OwnerClientId} eliminated.");
        }
    }
}
