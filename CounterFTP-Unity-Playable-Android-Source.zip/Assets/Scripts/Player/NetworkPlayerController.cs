using Unity.Netcode;
using UnityEngine;

namespace CounterFTP.Player
{
    /// <summary>
    /// Owner reads desktop or touch input. Server simulates movement, ammo, reload and hitscan.
    /// Required prefab components: NetworkObject, NetworkTransform (server authority),
    /// CharacterController, NetworkPlayerHealth, NetworkPlayerTeam.
    /// </summary>
    [RequireComponent(typeof(CharacterController))]
    public sealed class NetworkPlayerController : NetworkBehaviour
    {
        [Header("References")]
        [SerializeField] private Camera playerCamera;
        [SerializeField] private Transform muzzle;
        [SerializeField] private LayerMask hitMask = ~0;

        [Header("Movement")]
        [SerializeField] private float moveSpeed = 5.2f;
        [SerializeField] private float gravity = -20f;
        [SerializeField] private float desktopLookSensitivity = 2.0f;
        [SerializeField] private float touchLookSensitivity = 1.8f;

        [Header("Weapon")]
        [SerializeField] private float shotsPerSecond = 8f;
        [SerializeField] private float maxShotDistance = 180f;
        [SerializeField] private int damage = 25;
        [SerializeField] private int magazineSize = 30;
        [SerializeField] private int reserveAmmo = 90;
        [SerializeField] private float reloadDuration = 1.8f;

        public NetworkVariable<int> Magazine = new(30,
            NetworkVariableReadPermission.Everyone, NetworkVariableWritePermission.Server);
        public NetworkVariable<int> Reserve = new(90,
            NetworkVariableReadPermission.Everyone, NetworkVariableWritePermission.Server);

        private CharacterController _controller;
        private Vector2 _moveInput;
        private float _verticalVelocity;
        private float _yaw;
        private float _pitch;
        private float _lastShotTime;
        private float _reloadEndsAt;
        private bool _fireRequested;
        private bool _jumpRequested;
        private bool _reloadRequested;

        private void Awake() => _controller = GetComponent<CharacterController>();

        public override void OnNetworkSpawn()
        {
            if (playerCamera != null) playerCamera.gameObject.SetActive(IsOwner);
            if (IsServer)
            {
                Magazine.Value = magazineSize;
                Reserve.Value = reserveAmmo;
            }
            if (IsOwner)
            {
                Cursor.lockState = Application.isMobilePlatform ? CursorLockMode.None : CursorLockMode.Locked;
                Cursor.visible = Application.isMobilePlatform;
            }
        }

        public override void OnNetworkDespawn()
        {
            if (IsOwner)
            {
                Cursor.lockState = CursorLockMode.None;
                Cursor.visible = true;
            }
        }

        private void Update()
        {
            if (!IsOwner) return;

            Vector2 look = Vector2.zero;
            bool fire = false;
            bool jump = false;
            bool reload = false;

            if (MobileControls.Instance != null)
            {
                _moveInput = MobileControls.Instance.Move;
                look = MobileControls.Instance.ConsumeLookDelta() * touchLookSensitivity;
                fire = MobileControls.Instance.FireHeld;
                jump = MobileControls.Instance.ConsumeJump();
                reload = MobileControls.Instance.ConsumeReload();
            }
            else
            {
                _moveInput = Vector2.ClampMagnitude(
                    new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical")), 1f);
                look = new Vector2(Input.GetAxis("Mouse X"), Input.GetAxis("Mouse Y")) * desktopLookSensitivity;
                fire = Input.GetButton("Fire1");
                jump = Input.GetButtonDown("Jump");
                reload = Input.GetKeyDown(KeyCode.R);
            }

            _yaw += look.x;
            _pitch = Mathf.Clamp(_pitch - look.y, -85f, 85f);
            transform.rotation = Quaternion.Euler(0f, _yaw, 0f);

            if (playerCamera != null)
                playerCamera.transform.localRotation = Quaternion.Euler(_pitch, 0f, 0f);

            _fireRequested |= fire;
            _jumpRequested |= jump;
            _reloadRequested |= reload;
        }

        private void FixedUpdate()
        {
            if (!IsOwner) return;
            SubmitInputServerRpc(_moveInput, _yaw, _pitch, _fireRequested, _jumpRequested, _reloadRequested);
            _fireRequested = false;
            _jumpRequested = false;
            _reloadRequested = false;
        }

        [ServerRpc]
        private void SubmitInputServerRpc(Vector2 move, float yaw, float pitch,
            bool fire, bool jump, bool reload)
        {
            if (float.IsNaN(move.x) || float.IsNaN(move.y) ||
                float.IsNaN(yaw) || float.IsNaN(pitch)) return;

            move = Vector2.ClampMagnitude(move, 1f);
            _yaw = yaw;
            _pitch = Mathf.Clamp(pitch, -85f, 85f);

            if (_controller.isGrounded && _verticalVelocity < 0f)
                _verticalVelocity = -2f;

            if (jump && _controller.isGrounded)
                _verticalVelocity = 7f;

            _verticalVelocity += gravity * Time.fixedDeltaTime;
            Vector3 wishDirection = Quaternion.Euler(0f, _yaw, 0f) *
                                    new Vector3(move.x, 0f, move.y);
            Vector3 velocity = wishDirection * moveSpeed;
            velocity.y = _verticalVelocity;
            _controller.Move(velocity * Time.fixedDeltaTime);
            transform.rotation = Quaternion.Euler(0f, _yaw, 0f);

            if (reload) ServerReload();
            if (fire) ServerFire();
        }

        private void ServerReload()
        {
            if (!IsServer || Time.time < _reloadEndsAt) return;
            if (Magazine.Value >= magazineSize || Reserve.Value <= 0) return;
            _reloadEndsAt = Time.time + reloadDuration;
            Invoke(nameof(CompleteReload), reloadDuration);
        }

        private void CompleteReload()
        {
            if (!IsServer) return;
            int needed = magazineSize - Magazine.Value;
            int loaded = Mathf.Min(needed, Reserve.Value);
            Magazine.Value += loaded;
            Reserve.Value -= loaded;
        }

        private void ServerFire()
        {
            if (!IsServer || Time.time < _reloadEndsAt) return;
            float interval = 1f / Mathf.Max(1f, shotsPerSecond);
            if (Time.time - _lastShotTime < interval) return;
            if (Magazine.Value <= 0) return;

            _lastShotTime = Time.time;
            Magazine.Value--;

            Vector3 origin = muzzle != null ? muzzle.position : transform.position + Vector3.up * 1.5f;
            Vector3 direction = Quaternion.Euler(_pitch, _yaw, 0f) * Vector3.forward;

            if (Physics.Raycast(origin, direction, out RaycastHit hit, maxShotDistance,
                    hitMask, QueryTriggerInteraction.Ignore))
            {
                var health = hit.collider.GetComponentInParent<NetworkPlayerHealth>();
                if (health != null && health.OwnerClientId != OwnerClientId)
                    health.ApplyDamage(damage);
            }
        }
    }
}
