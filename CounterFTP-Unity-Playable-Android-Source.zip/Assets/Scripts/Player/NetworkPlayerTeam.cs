using Unity.Netcode;
using UnityEngine;

namespace CounterFTP.Player
{
    public enum TeamId : byte
    {
        Unassigned = 0,
        Terrorists = 1,
        CounterTerrorists = 2
    }

    /// <summary>Server-owned team assignment replicated to all connected clients.</summary>
    public sealed class NetworkPlayerTeam : NetworkBehaviour
    {
        public NetworkVariable<TeamId> Team = new(
            TeamId.Unassigned,
            NetworkVariableReadPermission.Everyone,
            NetworkVariableWritePermission.Server);

        public void SetTeamServer(TeamId team)
        {
            if (IsServer) Team.Value = team;
        }
    }
}
