# COUNTER FTP — Unity 6 / 5v5 Tactical FPS Starter

## Embedded Unity server (Listen Server)
The game uses a **listen-server** model. When a player presses **Create Match**, their game process calls Unity Netcode `StartHost()`. That same running game is both:
- the host's playable client (player 1);
- the authoritative server for the session.

There is no separate server app to install or launch. Up to **10 players total** can join: the host plus up to nine remote clients. The session setup sets `MaxConnectedClients = 10`. A simple alternating team assignment component places players into Terrorists and Counter-Terrorists.

## Important network limitation
A listen server is convenient for friends and casual matches, but the host has physical control of the server machine. A malicious host can cheat or alter game state. For ranked/competitive play, use a dedicated authoritative server. Direct IP connections may need UDP port forwarding; internet NAT traversal is not automatically solved by direct IP. Add Unity Relay/Lobby for easier public matchmaking and NAT traversal.

## Maps and intellectual property
The project includes an original graybox map generator called `Dustyard` with A/B sites and tactical lanes. The planned art direction is inspired by classic tactical FPS games, but official Counter-Strike maps, logos, models, sounds, textures, and other protected assets are not included. Create original maps or use assets with appropriate licenses.

## Included code
- Unity Netcode for GameObjects + Unity Transport
- embedded host/server creation and client joining
- 10-player total session capacity
- basic alternating team assignment
- server-authoritative round clock (150 seconds)
- server-side hitscan raycast and damage
- server-side movement simulation prototype
- basic fire-rate and input sanity checks
- original procedural graybox map generator

## Unity setup
1. Install Unity 6 (6000.0.40f1 or compatible Unity 6 release).
2. Open this folder in Unity Hub.
3. Wait for Package Manager to resolve dependencies from `Packages/manifest.json`.
4. Create `Assets/Scenes/Main.unity`.
5. Add a GameObject named `NetworkManager`; add `NetworkManager` and `UnityTransport`.
6. Assign UnityTransport in NetworkManager. Set the Player Prefab and register it under Network Prefabs.
7. Player Prefab components: `NetworkObject`, `CharacterController`, `NetworkTransform` (server authority), `NetworkPlayerController`, `NetworkPlayerHealth`, `NetworkPlayerTeam`. Add child Camera and Muzzle and assign references.
8. Create a networked Match State object: `NetworkObject` + `MatchNetworkState`, then ensure it is spawned as a scene NetworkObject or spawned by the server.
9. Add a `Bootstrap` GameObject with `SessionMenu`, `DustyardBlockoutGenerator`, `QuickSessionDebugUI`; assign the SessionMenu reference in QuickSessionDebugUI.
10. Add scene to Build Profiles.

## Test locally
- Build a standalone player and run it.
- In the Editor, press Play and click Create Match.
- In the standalone player, enter the host machine's LAN IP and click Join.
- Repeat with more clients until 10 total players (host + 9 clients).
- To test all 10, use multiple machines or instances. One machine may not have enough resources.

## Android
Install Android Build Support, SDK/NDK Tools, and OpenJDK in Unity Hub. Build Settings / Build Profiles → Android. The host phone runs the embedded listen server and the game client together. Hosting on mobile can consume battery and heat the device; test on target devices and prefer stable Wi-Fi.

## Anticheat reality
This starter demonstrates server authority for basic movement/weapon hit resolution, but it is not a production anti-cheat. A host-run server cannot reliably police its own host. Add server-side validation, command rate limits, telemetry, replay review, secure account identity, and a dedicated server for ranked play.

## Mobile controls update
Touch controls are generated at runtime on Android: left move stick, right look pad, FIRE, JUMP and RELOAD. Weapon magazine/reserve ammo and reload are server-owned NetworkVariables. Attach `MobileHudBootstrap` to the scene Bootstrap object.
