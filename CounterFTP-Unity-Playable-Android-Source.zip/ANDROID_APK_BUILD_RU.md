# Сборка Counter FTP в APK

## Подготовка Unity
1. Установите Unity 6 через Unity Hub.
2. В Unity Hub → Installs → Add modules установите:
   - Android Build Support
   - Android SDK & NDK Tools
   - OpenJDK
3. Откройте проект CounterFTP-Unity.
4. Дождитесь загрузки пакетов из Packages/manifest.json.
5. Создайте сцену `Assets/Scenes/Main.unity` и выполните настройки из `Assets/Scenes/README_SCENE_SETUP.md`.
6. Добавьте сцену в File → Build Profiles → Android → Scene List.

## Конфигурация APK
В верхнем меню Unity:
`Counter FTP → Android → Configure Android APK`

Будут выставлены:
- Application ID: `com.counterftp.mobile`
- Minimum Android API: 26 (Android 8.0)
- Landscape orientation
- IL2CPP
- ARM64
- Legacy Input Manager (потому что текущий контроллер использует `Input.GetAxis`)

## Сборка
Выберите:
`Counter FTP → Android → Build APK`

Результат:
`Builds/Android/CounterFTP.apk`

Также можно использовать:
File → Build Profiles → Android → Build.

## Установка на телефон
1. Перенесите `CounterFTP.apk` на Android-устройство.
2. Разрешите установку приложений из выбранного источника, если Android запросит это.
3. Установите APK.
4. Для теста сети подключите хост и клиентов к одной Wi-Fi сети.
5. На первом телефоне нажмите Create Match. На остальных введите LAN IP хоста и UDP порт 7777.

## Важные ограничения текущего прототипа
- Сборка APK не создаёт автоматически готовую игру: сначала необходимо собрать сцену, настроить Player Prefab, NetworkManager и UI по инструкциям.
- Скрипт сборки настраивает APK, но не создаёт 3D-контент, анимации, touch-контроллер или полноценный matchmaking.
- Текущий PlayerController использует клавиатурно-мышиный Input API. Для реальной игры на телефонах нужно заменить его на экранный joystick/touch controls. Это следующий обязательный этап перед мобильным игровым тестом.
- Listen Server на телефоне может нагревать устройство и расходовать батарею. Стабильнее использовать Wi-Fi, а не мобильную сеть.
- Для игры через интернет добавьте Unity Relay/Lobby или реализуйте NAT traversal. Прямой IP часто требует настройки маршрутизатора.


## Сенсорное управление
В проект добавлены `MobileControls.cs` и `MobileHudBootstrap.cs`.
Добавьте `MobileHudBootstrap` на Bootstrap GameObject. На Android создаётся экранный HUD:
- виртуальный джойстик слева;
- зона поворота камеры справа;
- удерживаемая кнопка FIRE;
- JUMP и RELOAD.

`NetworkPlayerController` выбирает сенсорный ввод на мобильных платформах и клавиатуру/мышь в Editor/PC.
Боезапас и перезарядка управляются сервером и реплицируются NetworkVariables.

## Что требуется перед первой игрой
- Создать сцену и Player Prefab вручную по `Assets/Scenes/README_SCENE_SETUP.md`.
- Убедиться, что в Player Prefab добавлены `NetworkPlayerTeam` и `NetworkPlayerHealth`.
- Добавить `MobileHudBootstrap` на Bootstrap.
- Настроить камеру, muzzle, коллайдеры и слои попаданий.
- Создать спавны команд и убедиться, что игроки не появляются в одной точке.
- Проверить 2 устройства в одной Wi-Fi сети и затем тестировать 10 клиентов.
